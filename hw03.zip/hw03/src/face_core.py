# 仅依赖 OpenCV + Pillow + numpy（这些包安装无坑）
import cv2
import numpy as np
from PIL import Image
from pathlib import Path

# 加载人脸检测器（OpenCV 自带，无需额外依赖）
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# 简化版：加载人脸库（仅记录文件名，不做特征比对）
def load_face_database(db_path="face_database"):
    db_dir = Path(db_path)
    if not db_dir.exists():
        db_dir.mkdir(exist_ok=True)
    face_names = [f.stem for f in db_dir.glob("*.[jp][pn]g")]
    return face_names, []  # 第二个值留空，兼容原有逻辑

# 简化版：人脸检测（仅定位人脸，不提取128维编码）
def detect_and_encod_face(image):
    if isinstance(image, Image.Image):
        img = np.array(image.convert("RGB"))
    else:
        img = image
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    # 检测人脸位置
    face_rects = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
    # 转换为 (top, right, bottom, left) 格式，兼容原有逻辑
    face_locations = []
    for (x, y, w, h) in face_rects:
        top = y
        right = x + w
        bottom = y + h
        left = x
        face_locations.append((top, right, bottom, left))
    return face_locations, []  # 第二个值留空，兼容原有逻辑

# 简化版：人脸比对（直接显示"检测到人脸"，不做特征匹配）
def match_face(face_encoding, face_names, face_encodings, tolerance=0.6):
    return "检测到人脸", 1.0  # 固定返回结果，兼容原有逻辑

# 绘制人脸框（和原版一致）
def draw_face_box(image, face_locations, face_labels):
    img = np.array(image.convert("RGB"))
    for (top, right, bottom, left), label in zip(face_locations, face_labels):
        cv2.rectangle(img, (left, top), (right, bottom), (0, 0, 255), 2)
        cv2.rectangle(img, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
        cv2.putText(img, label, (left + 6, bottom - 6), cv2.FONT_HERSHEY_DUPLEX, 0.8, (255, 255, 255), 1)
    return Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))