# 1. 导入库和自定义函数（复制这部分）
import streamlit as st
from PIL import Image
from pathlib import Path
import sys
sys.path.append(str(Path(__file__).parent))
from face_core import load_face_database, detect_and_encod_face, match_face, draw_face_box

# 2. 页面基础配置（复制这部分）
st.set_page_config(
    page_title="人脸识别系统",
    page_icon="👤",
    layout="wide"
)
st.title("👤 基于face_recognition的人脸识别系统")
st.divider()

# 3. 侧边栏：人脸库管理（复制这部分）
st.sidebar.title("📚 人脸库配置")
refresh_db = st.sidebar.button("刷新人脸库")
if refresh_db or "face_names" not in st.session_state:
    st.session_state.face_names, st.session_state.face_encodings = load_face_database()
st.sidebar.info(f"已加载人脸数：{len(st.session_state.face_names)}")
st.sidebar.text("提示：将人脸图片放入face_database，点击刷新即可")

# 4. 图片输入区域（复制这部分）
col1, col2 = st.columns(2)
with col1:
    st.subheader("📤 上传本地图片")
    uploaded_file = st.file_uploader("请选择图片文件", type=["jpg", "png", "jpeg"])
with col2:
    st.subheader("📸 选择示例图片")
    example_dir = Path("examples")
    example_dir.mkdir(exist_ok=True)
    example_files = [f.name for f in example_dir.glob("*.[jp][pn]g")]
    if example_files:
        selected_example = st.selectbox("请选择示例", example_files)
        example_img_path = example_dir / selected_example
    else:
        st.info("examples目录暂无图片，可自行添加测试图")
        selected_example = None

# 5. 选择待处理图片（复制这部分）
if uploaded_file:
    img = Image.open(uploaded_file).convert("RGB")
elif selected_example:
    img = Image.open(example_img_path).convert("RGB")
else:
    img = None

# 6. 核心识别逻辑（复制这部分）
if img is not None:
    st.divider()
    col_left, col_right = st.columns(2)
    with col_left:
        st.subheader("原始图片")
        st.image(img, use_column_width=True)
    with col_right:
        st.subheader("人脸识别结果")
        with st.spinner("正在检测人脸并提取特征..."):
            face_locations, face_encodings = detect_and_encod_face(img)
            face_labels = []
            for face_enc in face_encodings:
                name, conf = match_face(face_enc, st.session_state.face_names, st.session_state.face_encodings)
                if conf > 0:
                    face_labels.append(f"{name}（置信度：{conf}）")
                else:
                    face_labels.append(name)
            result_img = draw_face_box(img, face_locations, face_labels)
            st.image(result_img, use_column_width=True)
            st.success(f"✅ 检测完成！共检测到 {len(face_locations)} 个人脸")
            if face_labels:
                st.write("📝 识别结果：", face_labels)
else:
    st.info("💡 请上传本地图片或在examples目录添加示例图，开始人脸识别")

# 7. 页脚（复制这部分）
st.divider()
st.caption("本系统基于face_recognition(dlib)和Streamlit开发 | 人工智能通识课程作业03")